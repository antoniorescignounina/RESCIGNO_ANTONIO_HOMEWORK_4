clear all;
close all;
clc;

load('ws_homework_4.mat');

mass=1.1;
gravity=9.81;
e3=[0 0 1]';
m=mass*eye(3);
Inertia_matrix=diag([1.2416,1.2416,2*1.2416]);
 



for i=1:1:length(linear_vel.signals.values)
    dp(i,1)=linear_vel.time(i);
    dp(i,2:4)=linear_vel.signals.values(i,:);
end



for i=1:1:length(attitude.signals.values)
nb(i,1)=attitude.time(i);
nb(i,2:4)=attitude.signals.values(i,:);
end

for i=1:1:length(attitude_vel.signals.values)
nb_dot(i,1)=attitude.time(i);

nb_dot(i,2:4)=attitude_vel.signals.values(i,:);
end
 
 for i=1:1:length(thrust.signals.values)
    u_t(i,1)=thrust.time(i);
    u_t(i,2)=thrust.signals.values(i);
    
 end
 
 
 for i=1:1:length(tau.signals.values)
tau_x(i,1)=tau.time(i);
tau_x(i,2)=tau.signals.values(i,1);
end

for i=1:1:length(tau.signals.values)
tau_y(i,1)=tau.time(i);
tau_y(i,2)=tau.signals.values(i,2);
end

for i=1:1:length(tau.signals.values)
tau_z(i,1)=tau.time(i);
tau_z(i,2)=tau.signals.values(i,3);
end

tau=[tau_x(:,1) tau_x(:,2) tau_y(:,2) tau_z(:,2)];



wn=1;

r=3;


switch r
case{1}
p=([1 wn]);
case{2}
p=([1 1.4*wn wn^2]);
case{3}
p=([1 1.75*wn 2.15*wn^2 wn^3]);
case{4}
p=([1 2.1*wn 3.4*wn^2 2.7*wn^3 wn^4]);

otherwise
p=[]
warning('case not considered in ITAE');
end
k=p;
coeff=k;

for i=1 : r-1
    k = conv(coeff,p(1+i));
    coeff=k;
end

switch r
    case{1}
        K1=k(1);
        K2=1;
        K3=1;
        K4=1;
       
    case{2}
        
    
        K4=1;
        K3=1;
        K2=k(1);
        K1=k(2)/k(2);

case{3}
      
        K4=1;
        K3=k(1);
        K2=k(2)/K3;
        K1=k(3)/(K2*K3);
case{4}
       
        K4=k(1);
        K3=k(2)/K4;
        K2=k(3)/(K3*K4);
        K1=k(4)/(K2*K3*K4);
end
